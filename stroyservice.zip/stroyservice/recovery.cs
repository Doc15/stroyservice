﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace stroyservice
{
    public partial class recovery : Form
    {
        public recovery()
        {
            InitializeComponent();
        }

        private void back_Click(object sender, EventArgs e)
        {
            login win = new login();
            win.Show();
            this.Hide();
        }

        private void aBut_Click(object sender, EventArgs e)
        {
            if (passBox1.Text == passBox.Text)
            {
                // update in users
                string query = "update users set password ='" + passBox.Text + "' where login ='admin';";
                MySqlConnection conn = DBUtils.GetDBConnection();
                MySqlCommand cmDB = new MySqlCommand(query, conn);
                cmDB.CommandTimeout = 60;
                try
                {
                    conn.Open();
                    MySqlDataReader rd = cmDB.ExecuteReader();
                    conn.Close();
                    MessageBox.Show("Доступ восстановлен");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else MessageBox.Show("Значения не совпадают", "Ошибка");
        }
    }
}
