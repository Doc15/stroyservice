﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace stroyservice
{
    class DBUtils
    {
        public static MySqlConnection GetDBConnection()
        {
            string host = "89.108.102.54";
            int port = 3306;
            string database = "stroyservice";
            string username = "root";
            string password = "root";

            return DBMySQLUtils.GetDBConnecction(host, port, database, username, password);
        }
    }
}
