﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PagedList;

namespace stroyservice
{
    public partial class employee : Form
    {
        public employee()
        {
            InitializeComponent();
            getInfo(dataGridView1);
            getPosition(boxPosition);
            getTeam(teamBox);
            getStatus(statusBox);
        }
        void getPosition(ComboBox positionBox)
        {
            string query = "select titlePosition from ppositions";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            MySqlDataReader rd;
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        string row = rd.GetString(0);
                        positionBox.Items.Add(row);
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //выбор бригады
        void getTeam(ComboBox teamBox)
        {
            string query = "select number from team";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            MySqlDataReader rd;
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        string row = rd.GetString(0);
                        teamBox.Items.Add(row);
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //выбор статуса
        void getStatus(ComboBox statusBox)
        {
            string query = "select status from  status_e";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            MySqlDataReader rd;
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        string row = rd.GetString(0);
                        statusBox.Items.Add(row);
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void getInfo(DataGridView grid)
        {
            string query = "select FML, titlePosition, number, status from employee join  status_e on id_st=id_status join position on id_pos = id_position join team on id_t = id_team";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        dataGridView1.Rows.Add(rd.GetString(0), rd.GetString(1), rd.GetString(2), rd.GetString(3));
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //addpo
        private void button3_Click(object sender, EventArgs e)
        {
            addPosition win = new addPosition();
            win.Show();
            this.Hide();
        }
        //addt
        private void button4_Click(object sender, EventArgs e)
        {
            addTeam win = new addTeam();
            win.Show();
            this.Hide();
        }
        //menu
        private void button2_Click(object sender, EventArgs e)
        {
            Mmenu win = new Mmenu();
            win.Show();
            this.Hide();
        }
        //del
        private void button6_Click(object sender, EventArgs e)
        {
                DialogResult dialogResult = MessageBox.Show("Удалить?", "Подтверждение", MessageBoxButtons.OKCancel);
                if (dialogResult == DialogResult.OK)
                {
                    //удаление и сообщение о успешном удалении
                    string query = "delete from employee where id_empl= '" + dataGridView1.SelectedRows[0].Index + "';";
                    MySqlConnection conn = DBUtils.GetDBConnection();
                    MySqlCommand cmDB = new MySqlCommand(query, conn);
                    cmDB.CommandTimeout = 60;
                    try
                    {
                        conn.Open();
                        MySqlDataReader rd = cmDB.ExecuteReader();
                        conn.Close();
                        foreach (DataGridViewRow dgvrCurrent in dataGridView1.SelectedRows)
                        {
                            if (dgvrCurrent == dataGridView1.CurrentRow)
                            {
                                dataGridView1.CurrentCell = null;
                            }
                        }
                        MessageBox.Show("Запись удалена");
                        titleBox.Clear();
                        boxPosition.SelectedIndex = 0;
                        teamBox.SelectedIndex = 0;
                        statusBox.SelectedIndex = 0;
                    }
                    catch
                    {
                        MessageBox.Show("Не удалось удалить запись", "Ошибка");
                    }
                }

            }
        // refresh
        private void button5_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            getInfo(dataGridView1);
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            titleBox.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            boxPosition.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            teamBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            statusBox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }
        
        //add
        private void button1_Click(object sender, EventArgs e)
        {
            string query = "insert into employee(FML, titlePosition, number, status) values('" + titleBox.Text + "', " + Convert.ToString(Convert.ToInt32(boxPosition.SelectedIndex) + 1) + ", " + Convert.ToString(Convert.ToInt32(teamBox.SelectedIndex) + 1) + ", " + Convert.ToString(Convert.ToInt32(statusBox.SelectedIndex) + 1) + ");";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                conn.Close();
                MessageBox.Show("Запись добавлена");
                titleBox.Clear();
                boxPosition.SelectedIndex = 0;
                teamBox.SelectedIndex = 0;
                statusBox.SelectedIndex = 0;
            }
            catch
            {
                MessageBox.Show("Не удалось добавить запись", "Ошибка");
            }
        }
        //print
        private void button7_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap objBmp = new Bitmap(this.dataGridView1.Width, this.dataGridView1.Height);
            dataGridView1.DrawToBitmap(objBmp, new Rectangle(0, 0, this.dataGridView1.Width, this.dataGridView1.Height));

            e.Graphics.DrawImage(objBmp, 120, 200);

            e.Graphics.DrawString("Сотрудники", new Font("Verdana", 20, FontStyle.Bold), Brushes.Black, new Point(200, 30));
        }
    }
}

