﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace stroyservice
{
    public partial class client : Form
    {
        public client()
        {
            InitializeComponent();
            getInfo(listView1);
        }

        //значения из таблицы
        void getInfo(ListView list)
        {
            string query = "select titleClient from client";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        string[] row = { rd.GetString(0) };
                        var listItem = new ListViewItem(row);
                        list.Items.Add(listItem);
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Mmenu win = new Mmenu();
            win.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Удалить?", "Подтверждение", MessageBoxButtons.OKCancel);
            if (dialogResult == DialogResult.OK)
            {
                //удаление и сообщение о успешном удалении
                string query = "delete from clients where id_cli= '" + listView1.Items[listView1.SelectedIndices[0]].Text + "';";
                MySqlConnection conn = DBUtils.GetDBConnection();
                MySqlCommand cmDB = new MySqlCommand(query, conn);
                cmDB.CommandTimeout = 60;
                try
                {
                    conn.Open();
                    MySqlDataReader rd = cmDB.ExecuteReader();
                    conn.Close();
                    foreach (ListViewItem item in listView1.SelectedItems)
                    {
                        listView1.Items.Remove(item);
                    }
                    MessageBox.Show("Запись удалена");
                }
                catch
                {
                    MessageBox.Show("Запись не удалена", "Ошибка");
                }
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string query = "update clients set titleClient='" + titleBox.Text + "' where id_cli=" + listView1.Items[listView1.SelectedIndices[0]].Text + ";";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                conn.Close();
                MessageBox.Show("Запись отредактирована");
            }
            catch
            {
                MessageBox.Show("Не удалось изменить запись", "Ошибка");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "insert into client(titleClient) values('" + titleBox.Text + "');";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                conn.Close();
                MessageBox.Show("Запись добавлена");
                titleBox.Clear();
            }
            catch
            {
                MessageBox.Show("Не удалось добавить запись", "Ошибка");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            getInfo(listView1);
        }
    }
}
