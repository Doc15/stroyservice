﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stroyservice
{
    public partial class Mmenu : Form
    {
        public Mmenu()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            client win = new client();
            win.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            employee win = new employee();
            win.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            objects win = new objects();
            win.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
