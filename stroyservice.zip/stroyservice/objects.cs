﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PagedList;

namespace stroyservice
{
    public partial class objects : Form
    {
        public objects()
        {
            InitializeComponent();
            getClient(clientBox);
            getInfo(dataGridView1);
            getTeam(teamBox);
            dateStart.Format = DateTimePickerFormat.Custom;
            dateStart.CustomFormat = "yyyy-MM-dd";
            dateEnd.Format = DateTimePickerFormat.Custom;
            dateEnd.CustomFormat = "yyyy-MM-dd";
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.AllowUserToAddRows = false;
        }

        //значения из таблицы
        void getInfo(DataGridView grid)
        {
            string query = "select titleClient, numberContract, id_team, dateStart, dateEnd, budgetMln, address from objects join client on id_cli=id_client join team on id_t=id_team;"; // запрос значений из таблицы
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        dataGridView1.Rows.Add(rd.GetString(0), rd.GetString(1), rd.GetString(2), rd.GetString(3), rd.GetString(4), rd.GetString(5), rd.GetString(6));
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // выбор клиентв
        void getClient(ComboBox clientBox)
        {
            string query = "select titleClient from client";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            MySqlDataReader rd;
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        string row = rd.GetString(0);
                        clientBox.Items.Add(row);
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // выбор бригады
        void getTeam(ComboBox teamBox)
        {
            string query = "select number from team";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            MySqlDataReader rd;
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        string row = rd.GetString(0);
                        teamBox.Items.Add(row);
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //update table
        private void refresh_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            getInfo(dataGridView1);
        }
        //delete
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Удалить?", "Подтверждение", MessageBoxButtons.OKCancel);
            if (dialogResult == DialogResult.OK)
            {
                //удаление и сообщение о успешном удалении
                string query = "delete from objects where id_obj= '" + dataGridView1.SelectedRows[0].Index + "';";
                MySqlConnection conn = DBUtils.GetDBConnection();
                MySqlCommand cmDB = new MySqlCommand(query, conn);
                cmDB.CommandTimeout = 60;
                try
                {
                    conn.Open();
                    MySqlDataReader rd = cmDB.ExecuteReader();
                    conn.Close();
                    foreach (DataGridViewRow dgvrCurrent in dataGridView1.SelectedRows)
                    {
                        if (dgvrCurrent == dataGridView1.CurrentRow)
                        {
                            dataGridView1.CurrentCell = null;
                        }
                    }
                    MessageBox.Show("Запись удалена");
                    clientBox.SelectedIndex = 0;
                    contrBox.Clear();
                    teamBox.SelectedIndex = 0;
                    dateStart.Value = DateTime.Now;
                    dateEnd.Value = DateTime.Now;
                    budBox.Clear();
                    addressBox.Clear();
                }
                catch
                {
                    MessageBox.Show("Не удалось удалить запись", "Ошибка");
                }
            }
        }
        //update
        private void updateBut_Click(object sender, EventArgs e)
        {
            string query = "update objects set id_client=" + Convert.ToString(Convert.ToInt32(clientBox.SelectedIndex) + 1) + ", numberContract=" + contrBox.Text + ", id_team=" + Convert.ToString(Convert.ToInt32(teamBox.SelectedIndex) + 1) + ", dateStart='" + dateStart.Text + "', dateEnd='" + dateEnd.Text + "', budgetMln=" + budBox.Text + ", address='" + addressBox.Text + "';";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                conn.Close();
                MessageBox.Show("Запись отредактирована");
                clientBox.SelectedIndex = 0;
                contrBox.Clear();
                teamBox.SelectedIndex = 0;
                dateStart.Value = DateTime.Now;
                dateEnd.Value = DateTime.Now;
                budBox.Clear();
                addressBox.Clear();
            }
            catch
            {
                MessageBox.Show("Не удалось изменить запись", "Ошибка");
            }
        }
        //add
        private void button1_Click(object sender, EventArgs e)
        {
            string query = "insert into objects(id_client, numberContract, id_team, dateStart, dateEnd, budgetMln, address) values(" + Convert.ToString(Convert.ToInt32(clientBox.SelectedIndex) + 1) + ", " + contrBox.Text + ", " + Convert.ToString(Convert.ToInt32(teamBox.SelectedIndex) + 1) + ", '" + dateStart.Text + "', '" + dateEnd.Text + "', " + budBox.Text + ", '" + addressBox.Text + "');";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            cmDB.CommandTimeout = 60;
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                conn.Close();
                MessageBox.Show("Запись добавлена");
                clientBox.SelectedIndex = 0;
                contrBox.Clear();
                teamBox.SelectedIndex = 0;
                dateStart.Value = DateTime.Now;
                dateEnd.Value = DateTime.Now;
                budBox.Clear();
                addressBox.Clear();
            }
            catch
            {
                MessageBox.Show("Не удалось добавить запись", "Ошибка");
            }
        }
        //search
        private void searchBut_Click(object sender, EventArgs e)
        {
            string query = "select titleClient, numberContract, id_team, dateStart, dateEnd, budgetMln, address from objects join client on id_cli=id_client join team on id_t=id_team  where concat(titleClient, numberContract, number, dateStart, dateEnd, budgetMln, address) like '%" + toSearch.Text + "%';"; // запрос значений из таблицы
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            try
            {
                conn.Open();
                MySqlDataReader rd = cmDB.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        dataGridView1.Rows.Clear();
                        dataGridView1.Rows.Add(rd.GetString(0), rd.GetString(1), rd.GetString(2), rd.GetString(3), rd.GetString(4), rd.GetString(5), rd.GetString(6));
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Запись не найдена" + ex.Message);
            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            clientBox.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            contrBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            teamBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            dateStart.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            dateEnd.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            budBox.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            addressBox.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
        }

        private void back_Click(object sender, EventArgs e)
        {
            Mmenu win = new Mmenu();
            win.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap objBmp = new Bitmap(this.dataGridView1.Width, this.dataGridView1.Height);
            dataGridView1.DrawToBitmap(objBmp, new Rectangle(0, 0, this.dataGridView1.Width, this.dataGridView1.Height));

            e.Graphics.DrawImage(objBmp, 30, 200);

            e.Graphics.DrawString("Строительные объекты", new Font("Verdana", 20, FontStyle.Bold), Brushes.Black, new Point(200, 30));

        }
    }
}
