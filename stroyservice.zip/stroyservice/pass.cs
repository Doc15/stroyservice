﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stroyservice
{
    public partial class pass : Form
    {
        public pass()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string pass = "1234";
            if (textBox1.Text == pass)
            {
                recovery win = new recovery();
                win.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Неверный пароль");
                login win = new login();
                win.Show();
                this.Hide();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            login win = new login();
            win.Show();
            this.Hide();
        }
    }
}
